/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tetris;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 *
 * @author User
 */
public class Tetris extends Application {
    
     // set up the scene 
    static Canvas canvas = new Canvas(200, 600);
    static GraphicsContext context = canvas.getGraphicsContext2D();
    static Group root = new Group(canvas);
    static Scene scene = new Scene(root,200,600);
    
    static Random rand = new Random();
    
    // tetrimino constants

    final static int [][] tetrimino1={{0,0,0},{1,1,1},{0,0,0}}; 
    final static int [][] tetrimino2={{0,1,0},{0,1,0},{0,1,0}};
    final static int [][] tetrimino3={{0,0,0},{1,1,1},{0,0,0}};
    final static int [][] tetrimino4={{0,1,0},{0,1,0},{0,1,0}}; 
    final static int [][] tetrimino5={{1,0,0},{1,1,1},{0,0,0}};
    final static int [][] tetrimino6={{0,1,1},{0,1,0},{0,1,0}};
    final static int [][] tetrimino7={{0,0,0},{1,1,1},{0,0,1}};
    final static int [][] tetrimino8={{0,1,0},{0,1,0},{1,1,0}};
    final static int [][] tetrimino9={{0,0,1},{1,1,1},{0,0,0}};
    final static int [][] tetrimino10={{0,1,0},{0,1,0},{0,1,1}};
    final static int [][] tetrimino11={{0,0,0},{1,1,1},{1,0,0}};
    final static int [][] tetrimino12={{1,1,0},{0,1,0},{0,1,0}};
    final static int [][] tetrimino13={{0,1,1},{1,1,0},{0,0,0}};
    final static int [][] tetrimino14={{0,1,0},{0,1,1},{0,0,1}};
    final static int [][] tetrimino15={{0,0,0},{0,1,1},{1,1,0}};
    final static int [][] tetrimino16={{1,0,0},{1,1,0},{0,1,0}};
    final static int [][] tetrimino17={{0,1,0},{1,1,1},{0,0,0}};
    final static int [][] tetrimino18={{0,1,0},{0,1,1},{0,1,0}};
    final static int [][] tetrimino19={{0,0,0},{1,1,1},{0,1,0}};
    final static int [][] tetrimino20={{0,1,0},{1,1,0},{0,1,0}};
    final static int [][] tetrimino21={{1,1,0},{0,1,1},{0,0,0}};
    final static int [][] tetrimino22={{0,0,1},{0,1,1},{0,1,0}};
    final static int [][] tetrimino23={{0,0,0},{1,1,0},{0,1,1}};
    final static int [][] tetrimino24={{0,1,0},{1,1,0},{1,0,0}};
    final static int [][] tetrimino25={{1,1,0},{1,1,0},{0,0,0}};
    final static int [][] tetrimino26={{0,0,0},{1,1,0},{1,1,0}};
    final static int [][] tetrimino27={{0,0,0},{0,1,1},{0,1,1}};
    final static int [][] tetrimino28={{0,1,1},{0,1,1},{0,0,0}};
    final static int [][][] tetriminoes ={tetrimino1,tetrimino2,tetrimino3,tetrimino4,tetrimino5,tetrimino6,tetrimino7,tetrimino8,tetrimino9,tetrimino10,tetrimino11,tetrimino12,tetrimino13,tetrimino14,tetrimino15,tetrimino16,tetrimino17,tetrimino18,tetrimino19,tetrimino20,tetrimino21,tetrimino22,tetrimino23,tetrimino24,tetrimino25,tetrimino26,tetrimino27,tetrimino28};
    
    static int tetriminoNum;
    static int xPos;
    static Tetrimino activeTetrimino;
    static int [][] squares  ={{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}};
    static String direction="";
    static boolean rotatable=true;
    
    static int row,col,y;
    static boolean isRowFull=false;

    
       // class for creating each body part of snake 
   public static class Tetrimino{
	int startX;
        int startY;
        int tetriminoNum;
        int rotation;
        boolean locked;
        int [][] squares;
        
	public Tetrimino(int x,int y,int num,int rotation,int [][] squares) {
            
		this.startX=x;
                this.startY=y;
                this.tetriminoNum=num;
                this.rotation=rotation;
                this.squares=squares;
                this.locked=false;
	}

}
    

   
    public static void nextTetrimino(){
        
        tetriminoNum=rand.nextInt(7);
        xPos=rand.nextInt(8);
        
        
        activeTetrimino= new Tetrimino(xPos,0,tetriminoNum,0,tetriminoes[tetriminoNum*4]);
        
      
    }
    
 
    public static void updateTetriminoes(){
        
        // clear canvas 
        context.clearRect(0,0,200,600);
        
        // draw background 
	context.setFill(Color.BLACK);
	context.fillRect(0,0,200,600);
                                
        // fill in squares 
        context.setFill(Color.WHITE);
        for(row=0;row<=29;row++){
            for(col=0;col<=9;col++){
						
		if(squares[row][col] == 1){
							
                    context.fillRect(col*20,row*20,20,20);
		}
						
				
            }
	}
        
        // draw active tetrimino 
        for(row=0;row<=2;row++){
            for(col=0;col<=2;col++){
						
		if(activeTetrimino.squares[row][col] == 1){
							
                    context.fillRect((activeTetrimino.startX+col)*20,(activeTetrimino.startY+row)*20,20,20);
                    
                    // check if activeTetrimino should be locked 
                    if(activeTetrimino.startY+row>=0){
                   
                        if(activeTetrimino.startY+row>=29 || squares[activeTetrimino.startY+row+1][activeTetrimino.startX+col]==1){
                            activeTetrimino.locked=true;
                        }
                    }
                }
            }
        }
        
        // move active tetrimino 
	if(direction =="left" && activeTetrimino.startX>0 && !activeTetrimino.locked && squares[activeTetrimino.startY][activeTetrimino.startX-1]==0 && squares[activeTetrimino.startY+1][activeTetrimino.startX-1]==0 && squares[activeTetrimino.startY+2][activeTetrimino.startX-1]==0 ){
            activeTetrimino.startX--;
	}
				
	else if(direction =="right" && activeTetrimino.startX<7 && !activeTetrimino.locked && squares[activeTetrimino.startY][activeTetrimino.startX+3]==0 && squares[activeTetrimino.startY+1][activeTetrimino.startX+3]==0 && squares[activeTetrimino.startY+2][activeTetrimino.startX+3]==0){
            activeTetrimino.startX++;
	}
				
	direction="";
        
        // rotate active tetrimino 
        if(rotatable && !activeTetrimino.locked){
            activeTetrimino.squares=tetriminoes[tetriminoNum*4+activeTetrimino.rotation];
        }
        
        rotatable=true;
        
        // decide what do if tetrimino is locked or not 
	if(!activeTetrimino.locked){
            activeTetrimino.startY++;
	}
                                
        else if(activeTetrimino.locked){
				

            // check if game is over 
					
            if(activeTetrimino.startY <=0){
                for(row=0;row<=29;row++){
                    for(col=0;col<=9;col++){
                        
                        squares[row][col]=0;
                    }
                }
                
                context.clearRect(0,0,200,600);
               
            }
					
            else if(activeTetrimino.startY>0){
						
						
		// fill in all squares that the locked tetrimino occupies 
		for(row=0;row<=2;row++){
                    for(col=0;col<=2;col++){
							
			if(activeTetrimino.squares[row][col] == 1){
                            squares[activeTetrimino.startY+row][activeTetrimino.startX+col]=1;
			}
                    }
		}
						
		// check if a row is full 
		for(row=0;row<=29;row++){
						
                    isRowFull=true;
							
                    for(col=0;col<=9;col++){
							
			isRowFull=isRowFull && squares[row][col]!=0;
                    }
		
                    if(isRowFull){
			for(y=row;y>1;y--){
                            for(col=0;col<=9;col++){
										
				squares[y][col]=squares[y-1][col];
                            }
			}
									
			for(col=0;col<=9;col++){
                            squares[0][col]=0;
			}
                    }				
		}			
            }
            nextTetrimino();    
	}
    }
    
    
    @Override
    public void start(Stage primaryStage) {
        
        nextTetrimino();
        
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                
                updateTetriminoes();
                
               
            }
        },0,200); 

         // control
	scene.addEventFilter(KeyEvent.KEY_PRESSED, key -> {
            
            if (key.getCode() == KeyCode.A) {
                direction="left";
            }
            
	    if (key.getCode() == KeyCode.D ) {
                direction="right";
	    }
            
            if (key.getCode() == KeyCode.R ) {
                activeTetrimino.rotation++;
                
                if(activeTetrimino.rotation >=3){
                    activeTetrimino.rotation=0;
                }
                
                // check first to see if it is possible to rotate the piece 
                for(row=0;row<=2;row++){
                    for(col=0;col<=2;col++){
                        if(squares[activeTetrimino.startY+row][activeTetrimino.startX+col]==1){
                            rotatable=false;
                        }
                    }
                }
	    }

	});
        // show stage
        primaryStage.setScene(scene);
	primaryStage.setTitle("Tetris");
	primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}

